<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unique Furniture</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">

</script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "top_nav", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

</head>

<body>

<div id="templatemo_body_wrapper">
<div id="templatemo_wrapper">

<?php
include("header.php");
include("menubar.php");
include("categories.php");
include("bsbox.php");  ?>


        <div id="content" class="float_r">
            <h1> Products</h1>
            
<?php
include("connection.php");

$q="select *from product where stock>0 limit 15";
$res=mysqli_query($db,$q);
echo "<table>";
echo "<tr>";
$i=1;
$path="images/product/";
while($rows=mysqli_fetch_array($res))
{
?>  
    <div class="product_box">
	            <h3><?php echo $rows['6'];?></h3>
            	<a href="productdetail.php"><img src="<?php  echo $path.$rows['2']?>" height="200" width="200" alt=""/></a>

                <!-- <p> Fusce in dui et neque malesuada tincidunt nec at urna. Validate</p> -->
              <p class="product_price"><?php echo $rows['4'];?></p>
                <a href="add_to_cart.php?id=<?php echo $rows['0'];?>&path=<?php echo $rows['2'];?>&name=<?php echo $rows['1'];?>&quantity=<?php echo $rows['3'];?>&price=<?php echo $rows['4'];?>" class="addtocart"></a>

                <a href="productdetail.php?id=<?php echo $rows['0'];?>&path=<?php echo $rows['2'];?>&name=<?php echo $rows['1'];?>" class="detail"></a>
            </div>     


            <?php
                        if($i%3==0)
         {
           echo "<tr>";
         }

        $i++;
    }
    
echo "</table>";
?>   

            <!--div class="product_box">
            	<h3>Curabitur et turpis</h3>
            	<a href="productdetail.php"><img src="images/product/02.jpg" alt="Shoes 2" /></a>
                <p>Etiam et sapien ut nunc blandit euismod. Sed dui libero, semper a volutpat sed, placerat eu lectus.</p>
            <p class="product_price">$ 80</p>
                <a href="shoppingcart.php" class="addtocart"></a>
                <a href="productdetail.php" class="detail"></a>
            </div>        	
            <div class="product_box no_margin_right">
            	<h3>Mauris consectetur</h3>
            	<a href="productdetail.php"><img src="images/product/03.jpg" alt="Shoes 3" /></a>
                <p>Curabitur pellentesque ullamcorper massa ac ultricies. Maecenas porttitor erat quis leo pellentesque.</p>
              <p class="product_price">$ 60</p>
                <a href="shoppingcart.php" class="addtocart"></a>
                <a href="productdetail.php" class="detail"></a>
            </div>     
            
            <div class="cleaner"></div>
               	
            <div class="product_box">
            	<h3>Proin volutpat</h3>
            	<a href="productdetail.php"><img src="images/product/04.jpg" alt="Shoes 4" /></a>
                <p>Morbi non risus vitae est vestibulum tincidunt ac eget metus. Sed congue, erat id congue vehicula.</p>
              <p class="product_price">$ 260</p>
                <a href="shoppingcart.php" class="addtocart"></a>
                <a href="productdetail.php" class="detail"></a>
            </div>        	
            <div class="product_box">
	            <h3>Aenean tempus</h3>
            	<a href="productdetail.php"><img src="images/product/05.jpg" alt="Shoes 5" /></a>
                <p>Aenean eu elit arcu. Quisque eget blandit erat. Integer molestie malesuada augue vitae mollis.</p>
            <p class="product_price">$ 80</p>
                <a href="shoppingcart.php" class="addtocart"></a>
                <a href="productdetail.php" class="detail"></a>
            </div>        	
            <div class="product_box no_margin_right">
            	<h3>Nulla luctus urna</h3>
            	<a href="productdetail.php"><img src="images/product/06.jpg" alt="Shoes 6" /></a>
                <p>Nunc nisl nisi, aliquet eu gravida vitae, porta vel ante. Pellentesque faucibus risus et sem volutpat.</p>
              <p class="product_price">$ 190</p>
                <a href="shoppingcart.php" class="addtocart"></a>
                <a href="productdetail.php" class="detail"></a>
            </div>   
            
            <div class="cleaner"></div>
                 	
            <div class="product_box">
            	<h3>Pellentesque egestas</h3>
            	<a href="productdetail.php"><img src="images/product/07.jpg" alt="Shoes 7" /></a>
				<p>Aenean eu elit arcu. Quisque eget blandit erat. Integer molestie malesuada augue vitae mollis.</p>
              <p class="product_price">$ 30</p>
                <a href="shoppingcart.php" class="addtocart"></a>
                <a href="productdetail.php" class="detail"></a>
            </div>         	
            <div class="product_box">
            	<h3>Suspendisse porttitor</h3>
            	<a href="productdetail.php"><img src="images/product/08.jpg" alt="Shoes 8" /></a>
                <p>Nulla rutrum neque vitae erat condimentum eget malesuada neque molestie. Nunc a leo tellus.</p>
            <p class="product_price">$ 220</p>
                <a href="shoppingcart.php" class="addtocart"></a>
                <a href="productdetail.php" class="detail"></a>
            </div>        	
            <div class="product_box no_margin_right">
            	 <h3>Nam vehicula</h3>
            	<a href="productdetail.php"><img src="images/product/09.jpg" alt="Shoes 9" /></a>
               	<p>Vivamus accumsan luctus interdum. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
              <p class="product_price">$ 65</p>
                <a href="shoppingcart.php" class="addtocart"></a>
                <a href="productdetail.php" class="detail"></a>
            </div>   -->
        </div>
        <div class="cleaner"></div>
             <!--p class="pages"><small>Page 1 of 4 &nbsp;&nbsp;&nbsp;</small> 
            <!--?php echo "<a href='product.php?ci=0'>1</a>";?>
            <!--?php echo "<a href='allproduct.php?ci=9'>2</a>";?>
            <!--?php echo "<a href='allproduct.php?ci=18'>3</a>";?>
            <!--?php echo "<a href='allproduct.php?ci=27'>4</a>";?>
            <!--?php echo "<a href='allproduct.php?ci=36'>5</a>";?> 
            <a href="#">&raquo;</a></p>
			
    </div> <!-- END of templatemo_main -->
	</div>
    
<?php
include("footer.php");
 
?>
    
</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->

</body>
</html>