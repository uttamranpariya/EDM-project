<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unique Furniture</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">
    
</script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "top_nav", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

</head>

<body>

<div id="templatemo_body_wrapper">
<div id="templatemo_wrapper">

<?php
include("header.php");
include("menubar.php");
include("connection.php");
    global $total;
    
 $p="select *from order_tb";
    $res=mysqli_query($db,$p) or die("can't select");
?>
  <html>
  <head>
<style>
        table {
            margin-left: auto;
            margin-right: auto;
            font-size: 15px;
            width: 100%;
			height: 100%;
            table-layout:fixed;
        }
  
        
</style>
</head>
    <body>
		 <form name='f1' action='shoppinginfo.php' method='get'>
        <div id="templatemo_main">
        <br>


<title>unique Furniture </title>

           
       
        	<h1>Shopping Cart</h1>
                <table width="680px"  border="1" cellspacing="0" cellpadding="5">
                        <tr bgcolor="#ddd">
                            <th width="220" align="left">Image </th> 
                            <th width="180" align="left">Description </th> 
                            <th width="100" align="center">Quantity </th> 
                            <th width="30"  align="right">Price </th> 
                            <th width="100" align="center">Action</th>
                            
                        </tr>
                        <tr>
                        
            
              <?php
                
                $path="images/product/";        
    while($rows=mysqli_fetch_array($res))
    {?>   
      
        
        <td><img src="<?php echo $path.$rows['2'];?>" height=100 widht=100 ></td>
    
        <?php
    
        echo "<td>$rows[1]</td>";
        echo "<td align='center'><input type='text' name='t1[]' value='1' style='width: 20px; text-align: right'/></td>";
        echo "<td align='right'>$rows[4]</td> ";
        echo "<td><a href=order_delete.php?delete_id=".$rows[0].">Remove</a></td>";
        $total=$total+$rows[4];
                echo "</tr>";
                }?>
                           <tr>
                       
                           <td align="right" colspan="5"style=" font-weight:bold">Total:<?php echo $total;?> &emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; </td>
              
                        </tr>
                    </table>  
           
					

                    <div style="float:right; width: 215px; margin-top: 20px;">
                    
					<p><!--<a href="shoppinginfo.php">Proceed to checkout</a>-->
						<button type="submit">Proceed to checkout</button></p>
                    <p><button type="button" id="continue_shopping">Continue Shopping</button></p>
                    </div>
        <div class="cleaner"></div>
    </div> <!-- END of templatemo_main -->
			</form>
     <?php
			
include("footer.php");

?>
</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->
	
	<script>
		$( "#continue_shopping" ).click(function() {
			window.location.replace("http://localhost:82/furniture/products.php");
  //alert( "Handler for .click() called." );
});
	</script>
</body>
</html>   

	