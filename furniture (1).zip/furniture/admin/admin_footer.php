
<html>
    <body>
        <div id="templatemo_footer">
    	<p><a href="index.php">User</a> | <a href="product_list.php">Products</a> | <a href="order.php">Order</a> | <a href="category_list.php">Category</a> | <a href="feedback_list.php">Fedback</a> | <a href="bill_list.php">Checkout.php</a>
		</p>

    	 <p><a href="#">Unique furniture</a>
		 <div id="textbox"><strong><h5 align="center">unique Furniture:</strong><br/>
							Rajkot,<br/>
							uniquef@gmail.com<br/>
							</h5>
		 <div id="textbox"><strong><h5 align="center">Developed By:</strong><br>
							Bhalala Priyanshee<br>
							Andipara Mital<br/>
							</h5>
		  <!-- Credit: www.templatemo.com --></div> <!-- END of templatemo_footer -->
</body>
</html>

    