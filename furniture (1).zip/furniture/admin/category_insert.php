<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unique Furniture</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js"></script>

<script type="text/javascript">

ddsmoothmenu.init({
  mainmenuid: "top_nav", //menu DIV id
  orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
  classname: 'ddsmoothmenu', //class added to menu's outer DIV
  //customtheme: ["#1c5a80", "#18374a"],
  contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

</head>

<body>

<div id="templatemo_body_wrapper">
<div id="templatemo_wrapper">
  
 
	<?php
include("admin_header.php");
include("admin_menubar.php");
?>

<html>
    <body>
        <div id="templatemo_main">
        <br>

<head>
<title>unique Furniture </title>

<html>
<body>
<h1>Category form</h1>
<form method="post" enctype="multipart/form-data">
<table>
<tr>
<td>Category Name</td>
<td><input type="text" name="cname"placeholder="enter categoryname" pattern="^[A-Za-z]+"required/></td>
</tr>
<tr>
<td>Path</td>
<td><input type="text" name="path"placeholder="enter path" required/></td>
</tr>


<tr>
<td><input type="submit" name="submit" value="Add"/></td>
</tr>
</table>
</form>
</body>
</html>






<?php
include("connection.php");
if(isset($_REQUEST['submit']))
{
$cname=$_POST['cname'];
$path=$_POST['path'];


$iquery="insert into category(ID,name,path)values(NULL,'".$cname."','".$path."')";
$p1=mysqli_query($db,$iquery);
if($p1=1)
{ 
   echo "<script>window.location.href='category_list.php';</script>";

}
if($p1=0)
{echo"not inserted";
}
}
?>
<br>
  <br>
    <br>
    <br> 
    <br>
    <br>
     <br>
    <br>
    <br>
    <br>

 <div id="sidebar" class="float_l">
                    
          <div class="">
               
                       
            </div>
</body>
</html>


    

            <div class="cleaner"></div>
                  

            <div class="product_box no_margin_right">
             </div>         
        </div> 
        <div class="cleaner"></div>
    </div> <!-- END of templatemo_main -->
    
<?php
include("admin_footer.php");
?>

</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->

</body>