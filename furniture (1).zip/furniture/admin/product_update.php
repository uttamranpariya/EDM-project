<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unique Furniture</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="nivo-slider.css" type="text/css" media="screen" />

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">

</script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">


</script>

<script type="text/javascript">

ddsmoothmenu.init({
  mainmenuid: "top_nav", //menu DIV id
  orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
  classname: 'ddsmoothmenu', //class added to menu's outer DIV
  //customtheme: ["#1c5a80", "#18374a"],
  contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

</head>

<body>

<div id="templatemo_body_wrapper">
<div id="templatemo_wrapper">
<?php
include("admin_header.php");
include("admin_menubar.php");
?>

<html>
    <body>
        <div id="templatemo_main">
        <br>
<?php
include("connection.php");
$uid=$_GET['update_id'];
$uquery="select * from product where ID=".$uid;
$up_query=mysqli_query($db,$uquery);
$updata=mysqli_fetch_array($up_query);
?>
<h4 class="p2"> Update data</h4>
<form method="post" enctype="multipart/form-data">
<table>
<tr>
<td> Product Name</td>
<td><input type="text" name="pname" value="<?php echo $updata['1'];?>"/></td>
</tr>
<tr>
<td>Image</td>
<td><input type="file" name="img"  value="<?php echo $updata['2'];?>" /></td>
<td><img src="images/<?php echo $updata['2'];?>" height="100" width="100"/>
<input type="hidden" name="imgd" value="<?php echo $updata['2'];?>"/>
</td>
</tr>

<tr>
<td>stock</td>
<td><input type="text" name="stock"  value="<?php echo $updata['3'];?>"  /></td>
</tr>
<tr>
<tr>
<td>Price</td>
<td><input type="text"name="price"  value="<?php echo $updata['4'];?>"  /></td>


<tr>
<td>Description</td>
<td> <textarea name="dsc"  rows="10"  cols"100" ><?php echo $updata['5'];?></textarea></td>
</tr>
<tr>
<td>Product category</td>
<td> 
<select name="p_cat" >
<option <?php if($updata['6']=="Bedroom")
echo "selected"?>>Bedroom</option>
<option  <?php if($updata['6']=="Studyroom")
echo "selected"?>>Studyroom</option>
<option <?php if($updata['6']=="Livingroom")
echo "selected"?>>Livingroom</option>
<option  <?php if($updata['6']=="Kitchen")
echo "selected"?>>Kitchen</option>
</select>
</td>
</tr>
<tr>
<td><input type="submit" name="update"  value="UPDATE"/></td>
</tr>
</table>
</form>

<?php
if(isset($_REQUEST['update']))
{
$pname=$_POST['pname'];
$stock=$_POST['stock'];
$price=$_POST['price'];
$dsc=$_POST['dsc'];
$p_cat=$_POST['p_cat'];
if($_FILES['img']['name']!='')
{$imgg=$_FILES['img']['name'];
$dir="images/";
$tot=$dir.basename($imgg);
move_uploaded_file($_FILES['img']['tmp_name'],$tot);
}
else
{$imgg=$_POST['imgd'];
}
$update_query="update product set p_name='".$pname."',image='".$imgg."',stock=".$stock.",price=".$price.",description='".$dsc."',category='".$p_cat."' where ID='".$uid."'";

$updatedata=mysqli_query($db,$update_query);
if($updatedata=1)
{
	/*header("location:product_list.php");*/
  echo "<script>window.location.href='product_list.php';</script>";

}
}
?>

	<div id="sidebar" class="float_l">
                    
        	<div class="">
               
                       
            </div>
</body>
</html>


    

            <div class="cleaner"></div>
                 	

        </div> 
        <div class="cleaner"></div>
    </div> <!-- END of templatemo_main -->
    
<?php
include("admin_footer.php");
?>

</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->

</body>