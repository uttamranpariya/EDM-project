<html>
    <body>
	
<div id="templatemo_header">
<img src="images/logo-removebg-preview.png" width="300" height="100" align="left" title="Logo of a company" alt="Logo of a company" />
<!--div id="site_title"><h3>Unique Furniture</h3></div-->
        <div id="header_right">
		<!--img src="images/c3-removebg-preview.png" width="200" height="150" align="right" title="side titel" alt="side titel" /-->
		<p>
		<!--a href="register.php">Register</a> | <a href="logout.php">Log out</a> <!-- <a href="#">My Cart</a> | <a href="#">Checkout</a> | <a href="log_in.php">Log In</a> 
            <p>
            	Shopping Cart: <strong>3 items</strong> ( <a href="shoppingcart.php">Show Cart</a> )
			</p> -->
		<a href="logout.php" style="font-size:18px; ">Log out</a> 
		</div>
		
        <div class="cleaner"></div>
    </div> <!-- END of templatemo_header -->
</body>
</html>