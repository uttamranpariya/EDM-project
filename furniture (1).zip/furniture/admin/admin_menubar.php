<html>
    <body>
        <div id="templatemo_menubar">
    	<div id="top_nav" class="ddsmoothmenu">
            <ul>
                <li><a href="index.php" class="selected">User</a></li>
                <li><a href="product_list.php">Products</a>
                </li>
                <li><a href="order_list.php">Order</a>
                    <!--ul>
                        <li><a href="#submenu1">Sub menu 1</a></li>
                        <li><a href="#submenu2">Sub menu 2</a></li>
                        <li><a href="#submenu3">Sub menu 3</a></li>
                  </ul-->
                </li>
                 <li><a href="category_list.php">Category</a></li>
                <li><a href="feedback_list.php">Feedback</a></li>
                <li><a href="bill_list.php">Checkout</a></li>
			
            <!--     <li><a href="logout.php">Log out</a></li> -->
            </ul>
            <br style="clear: left" />
        </div> <!-- end of ddsmoothmenu -->
        <div id="templatemo_search">
            <form action="#" method="get">
              <input type="text" value=" " name="keyword" id="keyword" title="keyword" onFocus="clearText(this)" onBlur="clearText(this)" class="txt_field" />
              <input type="submit" name="Search" value=" " alt="Search" id="searchbutton" title="Search" class="sub_btn"  />
            </form>
        </div>
    </div> <!-- END of templatemo_menubar -->
</body>
</html>
