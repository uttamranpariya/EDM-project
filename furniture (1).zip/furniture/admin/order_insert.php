<html>
<body>
<h1>Order</h1>
<form method="post" enctype="multipart/form-data">
<table>


<tr>
<td>Order Product name</td>
<td><input type="text" name="o_p_name" placeholder="enter product name" required/></td>
</tr>
<td>Order Product quantity</td>
<td><input type="text"name="o_p_quantity" placeholder="enter product quantity" required/></td>
</tr>
<tr>
<td>Price</td>
<td><input type="text" name="o_price"  placeholder="price" required/></td>
</tr>
<tr>
<td><input type="submit" name="submit" /></td>
</tr>
</table>
</form>
</body>
</html>






<?php
include("connect.php");
if(isset($_REQUEST['submit']))
{

$o_p_name=$_POST['o_p_name'];
$o_p_quantity=$_POST['o_p_quantity'];
$o_price=$_POST['o_price'];
$iquery="insert into order_tb(o_id,o_p_name,o_p_quantity,o_price) values (NULL,'".$o_p_name."',".$o_p_quantity.",'".$o_price."')";
$p1=mysqli_query($db,$iquery);
if($p1=1)
{header("location:order_list.php?msg1=inserted");
}
if($p1=0)
{echo"not inserted";
}
}

?>