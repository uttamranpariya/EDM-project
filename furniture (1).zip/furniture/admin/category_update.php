<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unique Furniture</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="nivo-slider.css" type="text/css" media="screen" />

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">

</script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">


</script>

<script type="text/javascript">

ddsmoothmenu.init({
  mainmenuid: "top_nav", //menu DIV id
  orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
  classname: 'ddsmoothmenu', //class added to menu's outer DIV
  //customtheme: ["#1c5a80", "#18374a"],
  contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

</head>

<body>

<div id="templatemo_body_wrapper">
<div id="templatemo_wrapper">

<head>
<title>unique Furniture </title>
<?php
include("connection.php");
include("admin_header.php");
include("admin_menubar.php");
$uid=$_GET['update_id'];
$uquery="select * from category where ID=".$uid;
$up_query=mysqli_query($db,$uquery);
$updata=mysqli_fetch_array($up_query);
?>
<html>
    <body>
        <div id="templatemo_main">
          <br>


<html>
<body>
<section id="content">


<html>
<body>
<h1> Update data</h1>
<form method="post" enctype="multipart/form-data">
<table>
<tr>
<td>Category Name</td>
<td> <input type="text" name="cname"value="<?php echo $updata['1'];?>"></td>
</tr>
<tr>
<td>Path</td>
<td> <input type="text" name="path" value="<?php echo $updata['2'];?>"></td>
</tr>


<tr>
<td><input type="submit" name="update"  value="UPDATE"/></td>
</tr>
</table>
</form>
</body>
</html>


<?php
if(isset($_REQUEST['update']))
{
$cname=$_POST['cname'];
$path=$_POST['path'];


$update_query="update category set name='".$cname."', path='".$path."' where ID='".$uid."'";
$updatedata=mysqli_query($db,$update_query);
if($updatedata=1)
{  
   echo "<script>window.location.href='category_list.php';</script>";

}
}
?>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<div id="sidebar" class="float_l">
                    
          <div class="">
               
                       
            </div>
</body>
</html>


    

            <div class="cleaner"></div>
                  

            <div class="product_box no_margin_right">
             </div>         
        </div> 
        <div class="cleaner"></div>
    </div> <!-- END of templatemo_main -->

</body>
</html>
<?php
include("admin_footer.php");
?>

</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->

</body>
</html>
