<?php
include("connect.php");
$uid=$_GET['update_id'];
$uquery="select * from order_tb where o_id=".$uid;
$up_query=mysqli_query($db,$uquery);
$updata=mysqli_fetch_array($up_query);
?>


<html>
<body>
<h1> Update data</h1>
<form method="post" enctype="multipart/form-data">
<table>
<tr>
<td>Order Product name</td>
<td><input type="text" name="o_p_name"value="<?php echo $updata['1'];?>" required/></td>
</tr>
<td>Order Product quantity</td>
<td><input type="text"name="o_p_quantity" value="<?php echo $updata['2'];?>" required/></td>
</tr>
<tr>
<td>Price</td>
<td><input type="text" name="o_price" value="<?php echo $updata['3'];?>" required/></td>
</tr>
<td><input type="submit" name="update"  value="UPDATE"/></td>
</tr>
</table>
</form>
</body>
</html>


<?php
if(isset($_REQUEST['update']))
{

$o_p_name=$_POST['o_p_name'];
$o_p_quantity=$_POST['o_p_quantity'];
$o_price=$_POST['o_price'];
$update_query="update order_tb set o_p_name='".$o_p_name."',o_p_quantity=".$o_p_quantity.",o_price=".$o_price." where ID='".$uid."'";
$updatedata=mysqli_query($db,$update_query);
if($updatedata=1)
{header("location:order_list.php");
}
}
?>