<?php
include("connection.php");
$id=$_GET['delete_id'];
$delete_query="delete from category where ID=".$id;
$del_id1=mysqli_query($db,$delete_query);
if($del_id1=1)
{header("location:category_list.php");
}

?>