<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unique Furniture</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="nivo-slider.css" type="text/css" media="screen" />

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">

</script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">


</script>

<script type="text/javascript">

ddsmoothmenu.init({
  mainmenuid: "top_nav", //menu DIV id
  orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
  classname: 'ddsmoothmenu', //class added to menu's outer DIV
  //customtheme: ["#1c5a80", "#18374a"],
  contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

</head>

<body>

<div id="templatemo_body_wrapper">
<div id="templatemo_wrapper">

<head>
<title>unique Furniture </title>

<?php
include("admin_header.php");
include("admin_menubar.php");
include("Connection.php");
global $k;
$k=0;
$lim=isset($_GET['i'])?$_GET['i']:0;
$list_query="select * from bill limit $lim,10";
$data_query=mysqli_query($db,$list_query);
//$list_query="select * from bill";
//$data_query=mysqli_query($db,$list_query);
?>
<html>
    <body>
        <div id="templatemo_main">
          <br>

<html>
<head>
<style>
        table {
            margin-left: auto;
            margin-right: auto;
            font-size: 15px;
            width: 100%;
			height: 100%;
            table-layout:fixed;
        }
  
        
</style>
</head>
<body>
<h3>list of Bill</h3>
<table border="2">
<tr>
<th>
ID
</th>
<th>
Name
</th>
<th>
City
</th>
<th>
Quantity
</th>
<th>
Price</th>
<th>
Username
</th>
<th>
Type
</th>



<th colspan="1">
Action
</th>
</tr>
<?php
$path="images/product/";
while($list_data=mysqli_fetch_array($data_query)){?>
<tr>
<td><?php echo $list_data['0'];?></td>
<td><?php echo $list_data['1'];?></td>
<td><img src="<?php echo $path.$list_data['2'];?>" height="100" width="100"/></td>

<td><?php echo $list_data['3'];?></td>
<td><?php echo $list_data['4'];?></td>
<td><?php echo $list_data['5'];?></td>
<td><?php echo $list_data['6'];?></td>


<td><a href="bill_delete.php?delete_id=<?php echo $list_data['0'];?>">Delete</a></td>

</tr>
<?php } ?>
</table>
<?php
	static $i=0;
static 	$page=0;
//	$i=isset($_SESSION['i'])?$i:0;
	$qry=mysqli_query($db,"select *from bill");
	for($k=0;$k<=mysqli_num_rows($qry);$k++){
		if($k%10==0){
			//$i+=10;
			//$_SESSION['i']=$i;
			$page++;
		}
	}
	for($k=1;$k<=$page;$k++)
	{
			echo "<a href=bill_list.php?i=".$i.">".$k."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>";
			$i=$k*10;
	}
?>
</body>
</html>
<div id="sidebar" class="float_l">
                    
          <div class="">         
            </div>
</body>
</html>
       <div class="cleaner"></div>
                  

        </div> 
        <div class="cleaner"></div>
    </div> <!-- END of templatemo_main -->

</body>
</html>
<?php
include("admin_footer.php");
?>

</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->

</body>
</html>