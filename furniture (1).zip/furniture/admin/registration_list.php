<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unique Furniture</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="nivo-slider.css" type="text/css" media="screen" />

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">

</script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">


</script>

<script type="text/javascript">

ddsmoothmenu.init({
  mainmenuid: "top_nav", //menu DIV id
  orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
  classname: 'ddsmoothmenu', //class added to menu's outer DIV
  //customtheme: ["#1c5a80", "#18374a"],
  contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

</head>

<body>

<div id="templatemo_body_wrapper">
<div id="templatemo_wrapper">

<head>
<title>unique Furniture </title>
<?php

session_start();
if(!isset($_SESSION['ID']))
{
header("location:login.php");
}
else
{
include("admin_header.php");
include("admin_menubar.php");
include("Connection.php");
//$db=mysqli_connect("localhost", "root", "", "employees");
$list_query="select * from registration";
$data_query=mysqli_query($db,$list_query);
?>
<html>
    <body>
        <div id="templatemo_main">
          <br>





<html>
</html>head>
<style>
        table {
            margin-left: auto;
            margin-right: auto;
            font-size: 15px;
            width: 100%;
			height: 100%;
            table-layout:fixed;
        }
  
        
</style>
</head>
<body>

<h1> USER'S LIST  </H1>   
<table border="2">	
		<tr>
			<th>Id</th>
			<th>Name</th>			
			<th>Address</th>		
			<th>City</th>		
			<th>Mobile_no</th>		
			<th>Email</th>
			<!--th>Image</th-->
			<th colspan="1">Action</th>
		</tr>
		
		<?php  
			
			while($list_data=mysqli_fetch_array($data_query)){
		
		?>
		<tr>
			<td><?php echo $list_data['0'];  ?> </td>
			<td><?php echo $list_data['1'];?></td>
			<td><?php echo $list_data['2'];  ?> </td>
			<td><?php echo $list_data['3'];  ?> </td>
			<td><?php echo $list_data['4'];  ?> </td>
			<td><?php echo $list_data['5'];  ?> </td>
			
			
			
			<td><a href="registration_delete.php?delete_id=<?php echo $list_data['0'];?>">Delete</a></td>
			<!-- <td><a href="registration_update.php?update_id=<!--?php echo $list_data['ID']; ?>">UPDATE</a></td> -->
		</tr>
		
		<?php	}  ?>
	
	</table>
</body>
</html>
<div id="sidebar" class="float_l">
                    
          <div class="">
               
                       
            </div>
</body>
</html>


    

            <div class="cleaner"></div>
                  

            <div class="product_box no_margin_right">
             </div>         
        </div> 
        <div class="cleaner"></div>
    </div> <!-- END of templatemo_main -->

</body>
</html>
<?php
include("admin_footer.php");
}
?>

</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->

</body>
</html>


