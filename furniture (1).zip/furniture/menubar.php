<html>
    <body>
        <div id="templatemo_menubar">
    	<div id="top_nav" class="ddsmoothmenu">
            <ul>
                <li><a href="index.php" class="selected">Home</a></li>
                <li><a href="products.php">Products</a>
                    <ul>
                        <li><a href="bedroom.php">Bedroom</a></li>
                        <li><a href="kitchen.php">Kitchen</a></li>
                        <li><a href="livingRoom.php">Livingroom</a></li>
                        <li><a href="studyRoom.php">Studyroom</a></li>
                        
                  </ul>
                </li>
                <li><a href="about.php">About</a>
                    <!--ul>
                        <li><a href="#submenu1">Sub menu 1</a></li>
                        <li><a href="#submenu2">Sub menu 2</a></li>
                        <li><a href="#submenu3">Sub menu 3</a></li>
                  </ul-->
                </li>
                <li><a href="faqs.php">FAQs</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <?php
                    session_start();
                    if(!isset($_SESSION['id']))
                    { ?>
                <li><a href="login.php">Login</a></li>
                <?php
                }
              
              if(isset($_SESSION['id'])){
              ?>
             <li> <a href="logout.php">Log out</a></li>
                  <?php
                  }
                  ?>
            </ul>
            <br style="clear: left" />
        </div> <!-- end of ddsmoothmenu -->
        <div id="templatemo_search">
            <form action="#" method="get">
              <input type="text" value=" " name="keyword" id="keyword" title="keyword" onFocus="clearText(this)" onBlur="clearText(this)" class="txt_field" />
              <input type="submit" name="Search" value=" " alt="Search" id="searchbutton" title="Search" class="sub_btn"  />
            </form>
        </div>
    </div> <!-- END of templatemo_menubar -->
</body>
</html>
