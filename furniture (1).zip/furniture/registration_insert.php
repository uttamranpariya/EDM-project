<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unique Furniture</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="nivo-slider.css" type="text/css" media="screen" />

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">

</script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">


</script>

<script type="text/javascript">

ddsmoothmenu.init({
  mainmenuid: "top_nav", //menu DIV id
  orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
  classname: 'ddsmoothmenu', //class added to menu's outer DIV
  //customtheme: ["#1c5a80", "#18374a"],
  contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

</head>

<body>

<div id="templatemo_body_wrapper">
<div id="templatemo_wrapper">
<?php
    include("header.php");
    include("menubar.php");
?>

<head>
<title>unique Furniture </title>
<html>
    <body>
        <div id="templatemo_main">
          <br>
<html>
<body>

<h3 > Registration form</h3>
<form method="post" enctype="multipart/form-data">
<table>
<tr>
<td>Name</td>
<td><input type="text" name="name"placeholder="enter name" pattern="^[A-Za-z]+" title="name must have characters not digit.." required/></td>
</tr>
<tr>
<td>Address</td>
<td><textarea name="address" rows="4" placeholder="enter Address" pattern="^[A-Za-z]+" title="address must be filled.."required></textarea></td>
</tr>
<tr>
<td>City</td>
<td><input type="text" name="city" placeholder="enter City" pattern="^[A-Za-z]+" title="city name must have characters not any digit... "required/></td>
</tr>
<tr>
<tr>
<td>Mobile No</td>
<td><input type="text"name="mobile_no" placeholder="enter Mobile" pattern="[0-9]{10}" title="mobile no must be of 10 digit.."required/></td>
</tr>
<td>Email id</td>
<td><input type="text" name="email" placeholder="enter Email" pattern="[a-z0-9. %+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title="email must be validate.." required/></td>
</tr>
<tr>
<td>Password</td>
<td> <input type="password" name="password" placeholder="enter Password"pattern=".{6,}"  title="password must have at least 6 charactrs or digit.."required/></td>
</tr>
<tr>
<td> Confirm Password</td>
<td> <input type="password" name="confirm_password" placeholder="enter cpassword" pattern=".{6,}"required/></td>
</tr>
<tr>
<td><input type="submit" name="submit" /></td>
</tr>
</table>
</form><br />
<div align="left" style="color:#2f2f2f"><font size="+1">login here  </font><font size="+1"><a href="login.php"><u>Login</u></a></font></div>
</body>
</html>
<?php
include("connection.php");
if(isset($_REQUEST['submit']))
{
$name=$_POST['name'];
$email=$_POST['email'];
$address=$_POST['address'];
$mobile_no=$_POST['mobile_no'];
$city=$_POST['city'];
$password=$_POST['password'];
$confirm_password=$_POST['confirm_password'];
if($password!=$confirm_password)
{echo "enter same password";
}
else
{
$iquery="insert into registration(id,name,address,city,mobile_no,email,password) values (NULL,'".$name."','".$address."','".$city."',".$mobile_no.",'".$email."','".$password."')";

$p1=mysqli_query($db,$iquery);}
if($p1=1)
{  
	 echo "<script>window.location.href='login.php';</script>";
}
if($p1=0)
{echo"not inserted";
}
}
?>
 
</body
></html>

<div id="sidebar" class="float_l">
                    
          <div class="">
               
                       
            </div>
</body>
</html>
            <div class="cleaner"></div>         
        </div> 
        <div class="cleaner"></div>
    </div> <!-- END of templatemo_main -->

</body>
</html>
<?php
include("footer.php");
?>

</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->

</body>
</html>
