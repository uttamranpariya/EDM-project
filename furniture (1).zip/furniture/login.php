<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unique Furniture</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" href="nivo-slider.css" type="text/css" media="screen" />

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">

</script>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">


</script>

<script type="text/javascript">

ddsmoothmenu.init({
  mainmenuid: "top_nav", //menu DIV id
  orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
  classname: 'ddsmoothmenu', //class added to menu's outer DIV
  //customtheme: ["#1c5a80", "#18374a"],
  contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

</head>

<body>

<div id="templatemo_body_wrapper">
<div id="templatemo_wrapper">

<head>
<title>unique Furniture </title>

<?php            
ob_start();
/*session_start();
/*include_once("admin_header.php");*/
include("header.php");
include("menubar.php");
?>
<html>
    <body>
        <div id="templatemo_main">
          <br>


<form action="" method="post" id="formLogin">
<?php 
				 		global $total;
						global $cur;
						if(isset($_GET['cur'],$_GET['h1'])){
						$cur=$_GET['cur'];
						$total=$_GET['h1'];}
					?>
<input type="hidden" name="h1" value="<?php echo $total;?>"/>
<input type="hidden" name="cur" value="<?php echo $cur;?>"/>
    <div class="error-message"><?php if(isset($message)){ echo $message; }  ?>
    </div>
    <div class="field-group">
    <div align="center"><font size="+2" style="color:#000066"><label for="login">Username</label></font></div><br />
    <div align="center"><input type="text" name="email" class="input-field" required  autofocus/></div>
    </div>
    <br />
    <div class="field-group">
    <div align="center"><font size="+2" style="color:#000066"><label for="password">Password</label></font></div><br />
    <div align="center"><input type="password" name="password" class="input-field" required/></div>
    </div>
    <br />
    <div class="field-group">
    <div align="center"><input type="submit" style=" background-color:#FFFFFF; font-size : 20px; height: 45px; width: 100px" name="LOGIN" value="LOGIN" class="form-submit-button"/></div>

    
    
</div>
<br />
<br />
<div align="center" style="color:#2f2f2f"><font size="+1">You didn't registrate your self?</font><font size="+3"><a href="registration_insert.php"><u>Registration</u></a></font></div> 
<br>
<br>
<br>
<br>
<br>
<br>

<br>

</form>

</div>
<?php
include("connection.php");
$message="";
if(!empty($_POST["LOGIN"]))
{
    
	$result=mysqli_query($db,"SELECT * from registration WHERE email='".$_POST["email"]."' and password='".$_POST["password"]."'"); 
	$row=mysqli_fetch_array($result);
	if(is_array($row) && mysqli_num_rows($result)>0){
		$_SESSION["id"]=$row['id'];
		$_SESSION["email"]=$row['email'];
	}
	else
	{
		echo $message="Invalid username or password!!";
	}
}
if(isset($_SESSION["id"]))
{
	global $total;
		$total=$_GET['h1'];
		$cur=$_GET['cur'];
		if(isset($total,$cur))
		{
	header("location:checkout.php?h1=".$total."&id=".$row[0]."&cur=".$cur."");}
	else
	{
	header("location:checkout.php?h1=0&id=".$row[0]."&cur=0");
	}
}

?>
<div id="sidebar" class="float_l">
                    
          <div class="">
               
                       
            </div>
</body>
</html>
         <!--    <div class="cleaner"></div>        
        </div>  -->


        <div class="cleaner"></div>
    </div> <!-- END of templatemo_main -->

</body>
</html>
<?php
include("footer.php");

?>

</div> 
</div> 

</body>
</html>