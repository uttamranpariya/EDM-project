<?php
    include("connection.php");
    $prid=$_GET['id'];
    $prnm=$_GET['name'];
	$pr=$_GET['price'];
	$i=$_GET['path'];
	$stock=$_GET['quantity'];

		 $q="insert into order_tb(ID,pname,image,quantity,price) values($prid,'$prnm','$i','$stock','$pr')";
		
	$c=mysqli_query($db,$q) or die("can't insert");
?>
<?php include("shoppingcart.php");?>
