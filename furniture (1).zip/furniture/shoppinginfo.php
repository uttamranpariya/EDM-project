<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unique furniture</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">
</script>
<script type="text/javascript">

ddsmoothmenu.init({
  mainmenuid: "top_nav", //menu DIV id
  orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
  classname: 'ddsmoothmenu', 
  contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>


</head>

<body>

<div id="templatemo_body_wrapper">
<div id="templatemo_wrapper">

<?php
 include("header.php");
 include("menubar.php");
include("connection.php");
  global $total;
  global $cur;
  $p="select *from order_tb";
  $res=mysqli_query($db,$p) or die("can't select");
?>  
<html>
<head>
<style>
        table {
            margin-left: auto;
            margin-right: auto;
            font-size: 15px;
            width: 100%;
			height: 100%;
            table-layout:fixed;
        }
  
        
</style>
</head>
<body>
	<form name='f1' action='login.php' method='get'>
   <div id="templatemo_main">
        <br>
  <table width="680px" border="1" cellspacing="0" cellpadding="5">
                        <tr bgcolor="#ddd">
                          <th width="220" align="left">Image </th> 
                          <th width="180" align="left">Description </th> 
                            <th width="100" align="center">Quantity </th> 
                          <th width="30" align="right">Price </th> 
                          <th width="30" align="right">Total </th> 
                          <th width="100" align="center">Action</th>
                        </tr>
                      <tr>
            

        <?php 
        global $total;
        global $p;
        global $n;
        global $cur;
        //$uid=$_GET[id];
        $path="images/product/";
         $cur=current($_GET['t1']); 
  while($rows=mysqli_fetch_array($res))
  { 
       ?>
         
    <td><img src="<?php echo $path.$rows['2'];?>" height=100 widht=100></td>
    
        <td><?php echo $rows['1'];?></td>   
    <td align='center'><?php echo $cur;?></td>
    <?php
    //echo $cur;?><input type="hidden" name="cur" value="<?php echo $cur;?>"/><?php
    /*$i="insert into bill values('$rows[0]','$rows[2]','$rows[1]','$rows[3]',$cur)";
    mysql_query($i);*/
    echo "<td align='right'>$rows[4]</td> ";
  $to=$cur*$rows[4];
  echo "<td aling='right'>$to</td>";
    echo "</td>";
                echo "<td><a href=order_delete.php?delete_id=".$rows[0].">Remove</a></td>";
        $total=$total+$to;
        echo "</tr>";
        $cur=next($_GET['t1']);
        }?>  
         <tr>
         <input type="hidden" name="h1" value="<?php echo $total;?>"/>
                       
                           
                       
                           <td align="right" colspan="6"style=" font-weight:bold">Total:<?php echo $total;?> &emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; </td>
              
            </tr>
          </table>
                 <div style="float:right; width: 215px; margin-top: 20px;">
                    
          <p><button>procced to chechout</button></p>
                    <p><button type="button" id="continue_shopping">Continue Shopping</button></p>
                    </div>
                      
      
    <div id="sidebar" class="float_l">
                    
          <div class="">
               
                       
            </div>
</body>
</html>
            <div class="cleaner"></div>         
        </div> 
        <div class="cleaner"></div>
    </div> <!-- END of templatemo_main -->
	</form>
	<script>
		$( "#continue_shopping" ).click(function() {
			window.location.replace("http://localhost:82/furniture/products.php");
  //alert( "Handler for .click() called." );
});
	</script>

</body>
</html>
<?php
include("footer.php");
?>

</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->

</body>
</html>

