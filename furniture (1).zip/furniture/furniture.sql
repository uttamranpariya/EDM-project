-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 21, 2021 at 09:06 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `furniture`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `ID` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`ID`, `username`, `email`, `password`) VALUES
(1, 'admin', 'unique123@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `ID` int(11) NOT NULL,
  `p_name` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `quantity` int(30) NOT NULL,
  `price` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `b_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`ID`, `p_name`, `image`, `quantity`, `price`, `username`, `b_type`) VALUES
(2, 'fgh', 's12.jpeg', 1, 0, 'seeta', 'CASH PAYMENT'),
(3, 'fhujuy', 'c7.jpeg', 12, 0, 'seeta', 'CASH PAYMENT'),
(4, 'aaaa', 's1.jpeg', 4, 0, 'seeta', 'CASH PAYMENT'),
(5, 'bookshelves', 'book4.jpeg', 3, 55233, 'seeta', 'CASH PAYMENT'),
(6, 'chair', 'c7.jpeg', 7, 999, 'seeta', 'CASH PAYMENT'),
(8, 'bed', 'b7.jpeg', 12, 44100, 'seeta', 'CREDIT CARD'),
(9, 'sofa', 's1.jpeg', 8, 9999, 'seeta', 'CASH PAYMENT'),
(10, 'TV stand', 'tv4.jpeg', 20, 11999, 'seeta', 'CASH PAYMENT'),
(11, 'bed', 'b6.jpeg', 15, 22999, 'seeta', 'CASH PAYMENT'),
(12, 'bed', 'b10.jpeg', 12, 225000, 'seeta', 'CASH PAYMENT'),
(13, 'dining', 'd4.jpeg', 4, 25200, 'seeta', 'CREDIT CARD');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `ID` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `path` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`ID`, `name`, `path`) VALUES
(1, 'bedroom', 'bedroom.php'),
(4, 'kitchen', 'kitchen.php'),
(7, 'livingroom', 'livingroom.php'),
(8, 'studyroom', 'studyroom.php');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `ID` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(20) NOT NULL,
  `phone` int(11) NOT NULL,
  `message` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`ID`, `name`, `email`, `phone`, `message`) VALUES
(3, 'anjali', 'anjali@gmail.com', 702425841, 'nice job'),
(4, 'mital', 'anjali@gmail.com', 814748364, 'good collection'),
(5, 'priyansi', 'priyansibhalalala@gm', 947483647, 'good work'),
(6, 'Margi', 'margi123@gmailo.com', 2147483647, 'Nice Product.....'),
(7, 'Aryan', 'aryan18@gmail.com', 2147483647, 'super quality....'),
(8, 'sujal', 'sujal@gmail.com', 2147483647, 'hyyy good work');

-- --------------------------------------------------------

--
-- Table structure for table `order_tb`
--

CREATE TABLE `order_tb` (
  `ID` int(11) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_tb`
--

INSERT INTO `order_tb` (`ID`, `pname`, `image`, `quantity`, `price`) VALUES
(5, 'bookshelves', 'book4.jpeg', 5, 55233),
(9, 'bed', 'b8.jpeg', 8, 37899);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ID` int(11) NOT NULL,
  `p_name` varchar(15) NOT NULL,
  `image` varchar(100) NOT NULL,
  `stock` int(50) NOT NULL,
  `price` varchar(10000) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `category` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ID`, `p_name`, `image`, `stock`, `price`, `description`, `category`) VALUES
(1, 'sofa', 's1.jpeg', 8, '9999', ' Homes Studio Metal Queen sofa  (Finish Color - bl', 'Livingroom'),
(3, 'dining', 'd4.jpeg', 6, '25200', ' Homes Opus Engineered Wood King Box dining ', 'Kitchen'),
(4, 'TV stand', 'tv4.jpeg', 20, '11999', 'Homes Opus Engineered Wood Queen Box tv stand  ', 'Livingroom'),
(5, 'bookshelves', 'book4.jpeg', 5, '55233', 'Homes Carol Engineered Wood Queen\r\nbookshelves ', 'Studyroom'),
(6, 'bed', 'b6.jpeg', 15, '22999', ' Homes Opus Engineered Wood Queen Box Bed  ', 'Bedroom'),
(7, 'chair', 'c7.jpeg', 2, '999', ' Homes Solid Wood King chair  (Finish Color - light blue)', 'Livingroom'),
(8, 'bed', 'b7.jpeg', 1, '44100', ' Homes Waltz Engineered Wood King Box Bed ', 'Bedroom'),
(9, 'bed', 'b8.jpeg', 8, '37899', 'Homes Contemporary and Modern Solid Wood King Box ', 'Bedroom'),
(10, 'bed', 'b9.jpeg', 6, '10000', ' Homes Rhapsody Engineered Wood Queen Box Bed ', 'Bedroom'),
(11, 'bed', 'b10.jpeg', 8, '225000', 'Home by nilkamal Solid Wood Bed + Side Table ', 'Bedroom'),
(12, 'bed', 'b11.jpeg', 12, '33989', 'Bharat Lifestyle Amsterdam Engineered Wood Queen B', 'Bedroom'),
(13, 'bed', 'b12.jpeg', 11, '27400', ' Homes Waltz Engineered Wood Queen Box Bed  ', 'Bedroom'),
(14, 'bed', 'b13.jpeg', 3, '22200', 'Homes Carol Engineered Wood King Bed  ', 'Bedroom'),
(15, 'bed', 'b14.jpeg', 8, '10000', ' Perfect Homes Solid Wood Queen Bed\r\nPrimary Color Is Brown. Storage Included Is No. Bed Size Is Queen. Delivery Condition Is Knock Down. With Mattress Is No. Model Number Is Qu010. Suitable For Is Bedroom.', 'Bedroom'),
(16, 'study', 'c9jpeg.jpeg', 3, '2300', 'Wood Furniture Is Handcrafted By The Finest Artisans From Jodhpur/jaipur. Woodgrain, Color Variance', 'Studyroom'),
(17, 'bed', 'b16.jpeg', 7, '35999', 'Perfect Homes Junior Engineered Wood Single Bed\r\nWood\r\nPrimary Color Is Blue. Storage Included Is No. Bed Size Is Single. Delivery Condition Is Knock Down. With Mattress Is No. Model Number Is Pfj-blue-plain-bls02. ', 'Bedroom'),
(18, 'bookshelves', 'book1.jpeg', 3, '2000', 'BLUEWUD Maxelle Engineered Wood Open Book Shelf  (Finish Color - Brown, DIY(Do-It-Yourself))', 'StudyRoom'),
(19, 'bookshelve', 'book2.jpeg', 6, '3000', 'BLUEWUD Phelix Engineered Wood Open Book Shelf  (Finish Color - Wenge, Pre-assembled)', 'StudyRoom'),
(20, 'bookshelve', 'book4.jpeg', 12, '2500', 'G-KAMP JAPAN Plastic Open Book Shelf  (Finish Color - Pink, DIY(Do-It-Yourself))', 'StudyRoom'),
(21, 'bookshelve', 'book3.jpeg', 6, '3200', '@Home by nilkamal Checkers Engineered Wood Open Book Shelf  (Finish Color - Classic Walnut, Knock Down)', 'StudyRoom'),
(22, 'table', 'book5.jpeg', 5, '3500', '@Home by nilkamal Checkers Engineered Wood Open Book Shelf  (Finish Color - Classic Walnut, Knock Down)', 'Studyroom'),
(23, 'table', 'book6.jpeg', 4, '5000', 'Ebee Engineered Wood Computer Desk  (Modular, Finish Color - Wenge, DIY(Do-It-Yourself))', 'StudyRoom'),
(24, 'table', 'book10.jpeg', 6, '4500', ' Homes Engineered Wood Study Table  (Free Standing, Finish Color - Dark Wenge, Knock Down)', 'StudyRoom'),
(26, 'chair', 'c2.jpeg', 6, '23000', ' Fabric Office Executive Chair  (Black, Pre-assembled)', 'LivingRoom'),
(27, 'chair', 'c3.jpeg', 12, '4999', 'Wooden folding stool for living room | Wooden foldable stool, natural burnt finish, 12x12 inches Stool  (Brown, Pre-assembled)', 'LivingRoom'),
(28, 'chair', 'c5.jpeg', 12, '7999', 'Wooden folding stool for living room | Wooden foldable stool, natural burnt finish, 12x12 inches Stool  (Brown, Pre-assembled)', 'LivingRoom'),
(29, 'diningtable', 'd1.jpeg', 5, '33999', 'Homes Solid Wood 6 Seater Dining Set  (Finish Color -Provisional Teak, DIY(Do-It-Yourself))', 'Kitchen'),
(31, 'diningtable', 'd4.jpeg', 10, '34999', 'nilkamal SUTLEJ Solid Wood 4 Seater Dining Set  (Finish Color -Cherry, Knock Down)', 'Kitchen'),
(32, 'diningtable', 'd5.jpeg', 9, '65000', 'nilkamal SUTLEJ Solid Wood 4 Seater Dining Set  (Finish Color -Cherry, Knock Down)', 'Kitchen'),
(34, 'diningtable', 'd2.jpeg', 10, '55999', 'Nilkamal Carlos Engineered Wood 4 Seater Dining Set  (Finish Color -Walnut, Knock Down)', 'Kitchen'),
(35, 'diningtable', 'd3.jpeg', 7, '65290', 'KRIJEN Celtos Metal 4 Seater Dining Set  (Finish Color -white, Knock Down)', 'Kitchen'),
(36, 'TVstand', 'tv5.jpeg', 7, '23000', 'Forzza Holland Engineered Wood TV Entertainment Unit  (Finish Color - Black, Knock Down)', 'LivingRoom'),
(37, 'TVstand', 'tv1.jpeg', 5, '99999', ' Homes Sirena Engineered Wood TV Entertainment Unit  (Finish Color - Latin Walnut, Knock Down)', 'LivingRoom'),
(38, 'sofa', 's10.jpeg', 4, '43789', 'The Royal Nest Fabric 2 Seater Sofa  (Finish Color - Royal Grey, Pre-assembled)', 'Bedroom'),
(39, 'sofa', 's2.jpeg', 7, '34000', ' Homes Vegas Fabric 3 + 1 + 1 Beige Sofa Set  (Delivery condition - DIY(Do-It-Yourself))', 'Bedroom'),
(40, 'sofa', 's4.jpeg', 6, '43899', ' Homes Vegas Fabric 3 + 1 + 1 Beige Sofa Set  (Delivery condition - DIY(Do-It-Yourself))', 'LivingRoom');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `name` varchar(15) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` text NOT NULL,
  `mobile_no` bigint(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `name`, `address`, `city`, `mobile_no`, `email`, `password`) VALUES
(1, 'seeta', 'moviya', 'rjk', 9924258414, 'seeta@gmail.com', '123456'),
(3, 'geeta', 'rjk', 'rjk', 9924258414, 'geeta@gmail.com', '123456'),
(4, 'margi', 'kalavad road ', 'gondal', 9879840407, 'margi123@gmailo.com', 'margi12'),
(5, 'Aryan', 'Near sarvoday School', 'Surat', 6354398310, 'aryan18@gmail.com', 'aryanabc'),
(6, 'sujal', 'vasavad Road', 'Baroda', 9879800119, 'sujal@gmail.com', 'sujal987'),
(7, 'Karanpatel', 'Near taluka school', 'moviya', 9924258414, 'karan@gmail.com', 'karan123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `order_tb`
--
ALTER TABLE `order_tb`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `order_tb`
--
ALTER TABLE `order_tb`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
