<?php
include("connection.php");
$lid=$_GET['logout_id'];
?>

<?php
session_start();
unset($_SESSION["id"]);
echo "logout successfully";
session_destroy();
header("location:index.php");
?>