<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unique Furniture</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">

/***********************************************
* Smooth Navigational Menu- (c) Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/

</script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "top_nav", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

<script type="text/javascript" src="js/jquery-1-4-2.min.js"></script> 
<link rel="stylesheet" href="css/slimbox2.css" type="text/css" media="screen" /> 
<script type="text/JavaScript" src="js/slimbox2.js"></script> 


</head>

<body>

<div id="templatemo_body_wrapper">
<div id="templatemo_wrapper">

<?php
include("header.php");
include("menubar.php");
include("categories.php");
include("bsbox.php");  
?>  
<?php 
include("admin/connection.php");
$id=$_GET['id'];
$q="select * from  product where ID='$id'";
$result=mysqli_query($db,$q) or die("error");
?>
        <div id="content" class="float_r">
        	<h1>Product Detail</h1>

            <?php
            $path="images/product/";    
            while($row=mysqli_fetch_array($result))
            {
            ?>
            <div class="content_half float_l">
        	<a  rel="lightbox[portfolio]" href="<?php  echo $path.$row['2'];?>"><img src="<?php  echo $path.$row['2']?>" height="300" width="300" alt="image" /></a>
            </div>
            <div class="content_half float_r">
                <table>
                    <tr>
                        <td width="160">Product_name:</td>
                        <td><?php echo $row['1'];?></td>
                    </tr>
                    <tr>
                        <td>Category:</td>
                        <td><?php echo $row['6'];?></td>
                    </tr>
                    <tr>
                        <td>Price:</td>
                        <td><?php echo $row['4'];?></td>
                    </tr>
                    <tr>
                        <td>Stock:</td>
                        <td><?php echo $row['3'];?></td>
                    </tr>
                   
                </table>
                <div class="cleaner h20"></div>

                <a href="add_to_cart.php?id=<?php echo $row['0'];?>&path=<?php echo $row['2'];?>&name=<?php echo $row['1'];?>&quantity=<?php echo $row['3'];?>&price=<?php echo $row['4'];?>" class="addtocart"></a>

			</div>
            <div class="cleaner h30"></div>
            
            <h3>Product Description</h3>
            <p><?php
                
                $ar=explode("*",$row[5]);
                foreach($ar as $a)
                    {   
                        echo "&nbsp;&nbsp;<font size='+1'><td >".$a."<br/></td></font>";}
                ;
                ?>
            </p>	
            <?php
                }
               /* echo "</table>";*/
            ?>
         <!--    
          <div class="cleaner h50"></div>
            
            <h3>Related Products</h3>
        	<div class="product_box">
            	<a href="productdetail.php"><img src="images/product/01.jpg" alt="" /></a>
                <h3>Ut eu feugiat</h3>
                <p class="product_price">$ 100</p>
                <a href="shoppingcart.php" class="addtocart"></a>
                <a href="productdetail.php" class="detail"></a>
            </div>        	
            <div class="product_box">
            	<a href="productdetail.php"><img src="images/product/02.jpg" alt="" /></a>
                <h3>Curabitur et turpis</h3>
                <p class="product_price">$ 200</p>
                <a href="shoppingcart.php" class="addtocart"></a>
                <a href="productdetail.php" class="detail"></a>
            </div>        	
            <div class="product_box no_margin_right">
            	<a href="productdetail.php"><img src="images/product/03.jpg" alt="" /></a>
                <h3>Mauris consectetur</h3>
                <p class="product_price">$ 120</p>
                <a href="shoppingcart.php" class="addtocart"></a>
                <a href="productdetail.php" class="detail"></a>
            </div>     --> 
        </div> 
        <div class="cleaner"></div>
    </div> <!-- END of templatemo_main -->
    
<?php
include("footer.php");
?>
    
</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->

</body>
</html>