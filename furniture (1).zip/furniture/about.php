<!-- templatemo 367 shoes -->
<!-- 
Shoes Template 
http://www.templatemo.com/preview/templatemo_367_shoes 
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unique Furniture</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">

/***********************************************
* Smooth Navigational Menu- (c) Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/

</script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "top_nav", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

</head>

<body>

<div id="templatemo_body_wrapper">
<div id="templatemo_wrapper">

<?php
include("header.php");
?>	

  <?php
include("menubar.php");
?>  
    
 <?php
include("categories.php");
?>
 
 <?php
include("bsbox.php");  
?>  
        <div id="content" class="float_r">
        	<h1>About Us</h1>
        	<!--h2>Company Background</h2-->
            <p class="prev-indent-bot"> <b>Unique Furniture,As name suggest we provide the best wooden Furniture.<br/><br/>
        <!--p>Validate <a href="http://validator.w3.org/check?uri=referer" rel="nofollow">XHTML</a> &amp; <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow">CSS</a>. Donec sapien. Nam ac nunc. Aliquam fermentum cursus risus. Aliquam erat volutpat. Morbi a augue eget orci sodales blandit. Morbi et mi in mi eleifend adipiscing. Nullam id quam a ligula semper feugiat. Sed ultricies. Nulla et pede eu pede ultrices commodo. Nulla semper accumsan pede. Donec ut quam. Quisque egestas felis in diam.</p>
        <ul class="tmo_list">
        	<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
            <li>Pellentesque quis nulla id orci malesuada porta posuere quis massa.</li>
            <li>Nunc vitae purus non augue scelerisque ultricies vitae et velit quis.</li>
            <li>Aliquam fermentum cursus risus aliquam erat volutpat.</li>
            <li>Morbi a augue eget orci sodales blandit morbiet mi in mi eleifend adipiscing.</li>
		</ul-->
        The grain patterns on wood may vary depending on the species and way in which it is sawn </b></p>
           </article>
          <article class="grid_4">
            <h3 class="prev-indent-bot"></h3>
          <b> for example, Sheesham is grown across several regions of India, each with unique mineral soil compositions, resulting in grain pattern structures that are just characteristics of the natural beauty of the wood. Some furniture is deliberately aged to give it a more rustic feel.</b>
          </article>
        <div class="cleaner h20"></div>

        <!--h3>Management Team</h3>
		<p>Nam nec leo. Curabitur quis eros a arcu feugiat egestas. Nunc sagittis, dui non porttitor tincidunt, mi tortor tincidunt sem, et aliquet mi tortor eu turpis. Ut nisi ligula, viverra ac, placerat sed, ultricies vitae, neque. Morbi feugiat neque non odio eleifend pulvinar.</p-->
        <article class="grid_4">
            <h3 class="prev-indent-bot">why ??</h3>
			 <!--div class="quote"-->
              <p class="prev-indent-bot"><b>Furniture should always be comfortable and always have a piece of art that you made somewhere in  the HOME.......</b></p>
        <div class="cleaner"></div>
        <!--blockquote>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque quis nulla id orci malesuada porta posuere quis massa. Nunc vitae purus non augue scelerisque ultricies vitae et velit quis nulla id orci malesua.
        </blockquote-->
        <br/><br/>
            <b>In this cosmopolitan environment our house is an expression of our personality and sense of style whict is maintained by furniture,because furniture made our house BEAUTIFUL...</b> </article>
        </div> 
       
        <div class="cleaner"></div>
    </div> <!-- END of templatemo_main -->
    
    <?php
include("footer.php");
?>
    
</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->

</body>
</html>