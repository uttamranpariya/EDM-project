

<html>
    <body>
        <div id="templatemo_main">
    	<div id="sidebar" class="float_l">
        	<div class="sidebar_box"><span class="bottom"></span>
            	<h3>Categories</h3>   
                <div class="content"> 
                	<ul class="sidebar_list">
                    	<li class="first"><a href="products.php">All furniture</a></li>
						<?php
						include("connection.php");
 						 $q = "SELECT * FROM category";
 
    $res = mysqli_query($db,$q)or die("Can't Select");
    $rows = mysqli_num_rows($res);
    if($rows > 0)
    {
        while($data=mysqli_fetch_array($res))
        {?>
						
		 <li><a href="<?php echo $data['path']?>"><?php echo $data['name']?></a></li>
	<?php }
	}
		?>
  
                        <!--<li><a href="bedroom.php">Bedroom</a></li>
                        <li><a href="kitchen.php">Kitchen</a></li>
                        <li><a href="livingroom.php">Livingroom</a></li>
                        <li><a href="studyroom.php">Studyroom</a></li>
         -->               
                    </ul>
                </div>
            </div>
</body>
</html>
