<?php
include("connection.php");
global $total;
global $cur;
global $ne;
global $unm;
$unm=$_GET['l1'];
$ne=$_GET['b1'];
//$pa=$_GET['password'];
$total=$_GET['h1'];
$cur=$_GET['cur']; 

 $q = "SELECT * FROM order_tb";
	$res = mysqli_query($db,$q)or die("Can't fetch");
	$rows = mysqli_num_rows($res);
	if($rows > 0)
	{
		while($data=mysqli_fetch_array($res))
		{
			//print_r($data); exit;
		
		$id = $data[0]; 
		$pronm = $data[1]; 
		$path=$data[2];
		$pri=$data[3];
		$cur=$data[4];
		 $i="insert into bill values(NULL,'$pronm','$path','$pri',$cur,'$unm','$ne')"; 
		mysqli_query($db,$i)or die("can't insert");
		
		
	}	
	 $p = "SELECT *FROM product where ID='$id'";
	$res = mysqli_query($db,$p)or die("Can't Select");
	$rows = mysqli_num_rows($res);
	if($rows > 0)
	{
		while($data=mysqli_fetch_array($res))
		{
		
		$c = $data[3]; 
		}
		echo $c;
     $a=$c-$cur;
     echo $a;
     $s="update product set stock=$a where ID='$id'";

mysqli_query($db,$s)or die("can't update");
}
	}
	

if($ne=="CASH PAYMENT"){
include("submit.php");
}else{include("submitc.php");}
?>
