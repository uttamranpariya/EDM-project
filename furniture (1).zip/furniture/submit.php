<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unique Furniture</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">
</script>
<script type="text/javascript">

ddsmoothmenu.init({
  mainmenuid: "top_nav", //menu DIV id
  orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
  classname: 'ddsmoothmenu', 
  contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>


</head>

<body>

<div id="templatemo_body_wrapper">
<div id="templatemo_wrapper">

<?php
include("header.php");
include("menubar.php");
?>  
<script language="javascript">
function check()
{
  //var net=document.getElementsByName("t1");
var b1=document.getElementsByName("b1");

  if(b1[0].checked)
  {
    document.f1.action="cashpay.php";
    document.f1.submit();
  }
  else if(b1[1].checked)
  {
    document.f1.action="craditpay.php";
    document.f1.submit();
  } 
else
{
  alert("please choose any payment method");
}

}
</script>
<html>
    <body>
        <div id="templatemo_main">
        <br>
        <h2 class="p2">CASH PAYMENT</h2>  
<?php
$total=$_GET['h1'];
//echo $net;

echo "<form name='f1' action='#' method='GET'>";
//echo $net;
echo "<input type='checkbox' name='c1'>"."<font  style='Italic Bold' size=4>I agree to pay <b><u>Rs.";
echo $total;
echo "</u></b> in cash when the order is delivered to the shipping address";echo "</font>";
echo "<br><br><input type='button' value='CONFIRM ORDER' onClick='check();'>";

?>
  
         
 
     
<script language="javascript">
function check(){
var c1=document.getElementsByName("c1");
//alert(b1[0].checked);
if(c1[0].checked)
{
  
    document.f1.action="cmsg.php";
  
    document.f1.submit();
  
}


else
{
  alert("please click on checkbox");
}
}
</script>
<?php
echo "<form>";
include("connection.php");
$d="delete from order_tb";
mysqli_query($db,$d)or die("can't delete");
?><br><br><br><br>
        <div id="sidebar" class="float_l">
                    
          <div class="">
               
                       
            </div>
</body>
</html>
            <div class="cleaner"></div>         
        </div> 
        <div class="cleaner"></div>
    </div> <!-- END of templatemo_main -->

</body>
</html>
<?php
include("footer.php");
?>

</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->

</body>
</html>

