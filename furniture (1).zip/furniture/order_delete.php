<?php
include("connection.php");
$id=$_GET['delete_id'];
$delete_query="delete from order_tb where ID=".$id;
$del_id1=mysqli_query($db,$delete_query);
if($del_id1=1)
{header("location:shoppingcart.php");
}

?> 