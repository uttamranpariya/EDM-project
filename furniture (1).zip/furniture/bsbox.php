<html>
    <body>
        <div class="sidebar_box"><span class="bottom"></span>
            	<h3>Bestsellers </h3>   
                <div class="content"> 
                	<div class="bs_box">
                    	<a href="livingroom.php"><img src="images/temp_1.jpg" alt="image" /></a>
                        <h4><a href="livingroom.php">sofa</a></h4>
                        <p class="price">₹50000</p>
                        <div class="cleaner"></div>
                    </div>
                    <div class="bs_box">
                    	<a href="studyroom.php"><img src="images/temp.jpg" alt="image" /></a>
                        <h4><a href="studyroom.php">table</a></h4>
                        <p class="price">₹5000</p>
                        <div class="cleaner"></div>
                    </div>
                    <div class="bs_box">
                    	<a href="livingroom.php"><img src="images/temp_3.jpg" alt="image" /></a>
                        <h4><a href="livingroom.php">TV stand</a></h4>
                        <p class="price">₹14000</p>
                        <div class="cleaner"></div>
                    </div>
                    <div class="bs_box">
                    	<a href="kitchen.php"><img src="images/temp_4.jpg" alt="image" /></a>
                        <h4><a href="kitchen.php">storage</a></h4>
                        <p class="price">₹2000</p>
                        <div class="cleaner"></div>
                    </div>
                </div>
            </div>
        </div>
   </body>
</html>