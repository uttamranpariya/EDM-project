<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unique furniture</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">
</script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "top_nav", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

</head>

<body>

<div id="templatemo_body_wrapper">
<div id="templatemo_wrapper">

<?php
include("header.php");
include("menubar.php"); 
include ("connection.php");
?>  
<html>
    <body>
        <div id="templatemo_main">
        <br>
        <html>
        <body>
<?php  
    global $unm;
    global $no;
    global $email;
    global $mobi;
    global $addr;
    global $pin;
    global $city ;
    //$uid=$_GET['uid'];
   $q = "SELECT * FROM registration WHERE id=".$_SESSION["id"];
 
    $res = mysqli_query($db,$q)or die("Can't Select");
    $rows = mysqli_num_rows($res);
    if($rows > 0)
    {
        while($data=mysqli_fetch_array($res))
        {
        
        $no = $data[0];
        $unm = $data[1]; 
        $email = $data[5]; 
        $mobi = $data[4];   
        $addr = $data[2];   
        $city = $data[3]; 
         
    }
    }
    
?>
<head>
<title>unique Furniture </title>
        	<h2>Checkout</h2>
            <h5><strong>BILLING INFORMATION</strong></h5>
<?php
        echo "<form name='f1' action='sub.php' method='GET' onSubmit='return validate_form(this)'>";
global $total;
$total=$_GET['h1'];
global $cur;
//$cur=$_GET['cur'];?>
<input type="hidden" name="h1" value="<?php echo $total;?>"/><input type="hidden" name="cur" value="<?php echo $cur;?>"/>
<table>
 <tr><td>

     <label for="name"><?php echo "UserName";?></label></td>
              <td> <input type="text" name="l1" value="<?php echo $unm;?>" readonly="true" onKeyPress="return charonly(this, event)"  class="text">
              </td></tr>
              <tr><td>
                <label for="email"><?php echo "E_mail address";?></label></td>
              <td> <input type="text" name="e1" value="<?php echo $email;?>" readonly="true" class="text" >

               </td></tr>
               <tr><td>
                <label for="website"><?php echo "Mobile no";?></label></td>
              <td>  <input type="text" name="m1" value="<?php echo $mobi; ?>" maxlength=10 readonly="true" onKeyPress="return numbersonly(this, event)"  class="text"></td></tr>
                <tr><td>
                <label for="message"><?php echo "Address";?></label></td>
           <td> <textarea rowspan=5 name="a1" value="" readonly="true" class="text"><?php echo $addr;?></textarea></td>
</tr>
              

        <tr>  <td>
     <label for="name"><?php echo "City";?></label></td>
            <td> <input type="text" name="c1" value="<?php echo $city;?>" readonly="true" onKeyPress="return charonly(this, event)" class="text">
</td></tr></table>
<br>
<h5><strong>Delivery Mode:</strong></h5>
            <!-- <div class="content_half float_l checkout">
			  Name:  
                  <input type="text"  style="width:300px;"  />
                <br />
                
              E-MAIL
                <input type="text"  style="width:300px;"  />
                <br />
               
              Mobile_no
                <input type="text"  style="width:300px;"  />
                <br />
               
              Address:
				<input type="text"  style="width:300px;"  />
                <br />
            
           <div class="content_half float_r checkout">  -->
             <!--  City:
                <input type="text"  style="width:300px;"  />
                <br />
            </div> -->
             <!--   
                Country:
                <input type="text"  style="width:300px;"  />
            
            	E-MAIL
				<input type="text"  style="width:300px;"  />
                <br />
                
          PHONE<br />
				<span style="font-size:10px"></span>
                <input type="text"  style="width:300px;"  />
            </div>
             -->
            <!-- <div class="cleaner h50"></div>
            <h3>SHOPPING CART</h3>
            <h4>TOTAL AMOUNT: <strong>$240</strong></h4>
			<p><input type="checkbox" />
			I accept the <a href="#">terms of use</a> of this website.</p> -->
         
            <table style="border:1px solid #CCCCCC;" width="100%">
                <tr>
                    <td height="80px"> <img src="images\cod.jpeg" height="100" width="150"  alt="paypal" /></td>
                    <td width="400px;" style="padding: 0px 20px;">Recommended if you have a PayPal account. Fastest delivery time.
                    </td>
                    <td><?php echo"<a href='submit.php?total=".$total."'><input type='submit' value='CASH PAYMENT' name='b1'/></a>"; ?></td>
                </tr>
                <tr>
                    <td  height="80px"><img src="images/mastercard.jpeg" height="100" width="150" alt="paypal" />
                    </td>
                    <td  width="400px;" style="padding: 0px 20px;">2CheckOut accepts customer orders via online checks, Visa, MasterCard many Bank SBI ,Axix,BOB</td>
                    <td><a href="submitc.php"><input type="submit" value="CREDIT CARD" name="b1"/></a></td>
                </tr>
               
            </table>
            <tr>
<!-- <td><input type="submit" name="submit" /></td> -->
</tr>
       
        <div class="cleaner"></div>
    </div> <!-- END of templatemo_main -->
    
 <?php
include("footer.php");
?>
 
</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->

</body>
</html>