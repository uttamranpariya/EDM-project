<!-- templatemo 367 shoes -->
<!-- 
Shoes Template 
http://www.templatemo.com/preview/templatemo_367_shoes 
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unique Furniture</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">

/***********************************************
* Smooth Navigational Menu- (c) Dynamic Drive DHTML code library (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
***********************************************/

</script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "top_nav", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

</head>

<body>

<div id="templatemo_body_wrapper">
<div id="templatemo_wrapper">

<?php
include("header.php");
?>	
    
<?php
include("menubar.php");
?>

<?php
include("categories.php");
?>	
<?php
include("bsbox.php");  
?>  
        <div id="content" class="float_r faqs">
        	<h1>FAQs</h1>
            <h5>How do I  know if my order has been placed?</h5>
            <p>You will  receive an email confirming that your order has been received. If you do not  receive an email confirmation, please login to see your order status.  <!--Validate <a href="http://validator.w3.org/check?uri=referer" rel="nofollow">XHTML</a> &amp; <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow">CSS</a-->.</p>
            
          <h5>When will my order be shipped?</h5>
            <p>Please read our shipping policy. <!--Click <a href="#">here</a--></p>
            
            <h5>What payment methods do you accept?</h5>
            <p>Only Cash On Delivery</p>
            
            <h5>Can I return or exchange my purchase if I don't like it?</h5>
            <p>Please read our exchange policy. <!--Click <a href="#">here</a--></p>
            
            <h5>How do I know if online ordering is secured?</h5>
            <p>
            Protecting your information is a  top priority for this site. We use Secure Sockets Layer (SSL) to encrypt your number, name and address, so only this site is able to decode  your information. SSL is the industry standard method for computers to  communicate securely without risk of data interception, manipulation or  recipient impersonation. To be sure your connection is secure; when you are in  the Shopping Cart, look at the lower corner of your browser window. If you see  an unbroken key or closed lock, the SSL is active and your information is  secure.</p>
          <p>
          This site is registerd with HackerGuardian. HackerGuardian certification for  a hacker free website.</p>

			
            <h5>What is your privacy policy?</h5>
            <p>This website respects your privacy and ensure that  you understand what information we need to complete your order, and what  information you can choose to share with us and with our marketing partners.  For complete information on our privacy policy, please visit our <a href="#">Privacy Policy</a>  page.</p>
        </div> 
        <div class="cleaner"></div>
    </div> <!-- END of templatemo_main -->
    
 <?php
include("footer.php");
?>
    
</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->

</body>
</html>