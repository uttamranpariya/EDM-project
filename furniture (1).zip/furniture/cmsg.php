<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unique furniture</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">
</script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "top_nav", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

</head>

<body>

<div id="templatemo_body_wrapper">
<div id="templatemo_wrapper">

<?php
include("header.php");
include("menubar.php"); 
include ("connection.php");
?>  
<html>
    <body>
        <div id="templatemo_main">
        <br>
        <?php
echo "<form name='f1' action='#' method='GET'>";
echo "<font  style='Italic Bold' size=3>"."<b><u>Dear Guest</u></b><br><br><br>"." "."Thank you for placing your order with Unique furniture"."<br><br><br>";

echo "<b><u>Payment Status</u></b> : success"."<br><br><br>";
echo "<b><u>order placed on</u></b> : "?><?php
echo date('D F d g:i:s Y');echo "<br>";
//echo date('g-i-s');
//<font face='Monotype Corsiva' style='Italic Bold' size=+2>
//<font face='Monotype Corsiva' style='Italic Bold' size=+1>

echo "</font>";
?><br><br><br><br><br>
<div id="sidebar" class="float_l">
                    
          <div class="">
               
                       
            </div>
</body>
</html>
            <div class="cleaner"></div>         
        </div> 
        <div class="cleaner"></div>
    </div> <!-- END of templatemo_main -->

</body>
</html>
<?php
include("footer.php");
?>

</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->

</body>
</html>
