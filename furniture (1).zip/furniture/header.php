<html>
    <body>
	
<div id="templatemo_header">
<img src="images/logo-removebg-preview.png" width="300" height="100" align="left" title="Logo of a company" alt="Logo of a company" />
<!--div id="site_title"><h3>Unique Furniture Store</h3></div-->
        <div id="header_right">
		<!--img src="images/c3-removebg-preview.png" width="200" height="150" align="right" title="side titel" alt="side titel" /-->
		<p>
		<!--a href="#">My Account</a> | <a href="#">My Wishlist</a> | <a href="#">My Cart</a--> 
            <p>
            	Shopping Cart: ( <a href="shoppingcart.php" style="font-size:18px;" >Show Cart</a> ) | <!-- <a href="logout.php">Log out</a>  -->
            	
			</p>
		</div>
		
        <div class="cleaner"></div>
    </div> <!-- END of templatemo_header -->
</body>
</html>