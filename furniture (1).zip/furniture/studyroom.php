<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unique Furniture</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">


</script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "top_nav", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

</head>

<body>

<div id="templatemo_body_wrapper">
<div id="templatemo_wrapper">

<?php
include("header.php");
include("menubar.php");
include("categories.php");
include("bsbox.php");  ?>


<div id="content" class="float_r">
<h1> Products</h1>
            
<?php
	include("admin/connection.php");
	$q="select *from product where stock>0 && category='Studyroom'";
	$res=mysqli_query($db,$q);
	echo "<table>";
	echo "<tr>";
	$i=1;
	$path="images/product/";
	while($rows=mysqli_fetch_array($res))
	{
	?>  
	<div class="product_box">
	            <h3><?php echo $rows['6'];?></h3>
            	<a href="productdetail.php"><img src="<?php  echo $path.$rows['2']?>" height="200" width="200" alt=""/></a>

                
              <p class="product_price"><?php echo $rows['4'];?></p>
                <a href="add_to_cart.php?id=<?php echo $rows['0'];?>&path=<?php echo $rows['2'];?>&name=<?php echo $rows['1'];?>&quantity=<?php echo $rows['3'];?>&price=<?php echo $rows['4'];?>" class="addtocart"></a>
                
                <a href="productdetail.php?id=<?php echo $rows['0'];?>&path=<?php echo $rows['2'];?>&name=<?php echo $rows['1'];?>" class="detail"></a>
            </div>     


            <?php
                        if($i%3==0)
         {
           echo "<tr>";
         }

        $i++;
    }
    
echo "</table>";
?>   	
</div>
        <div class="cleaner"></div>
    </div> <!-- END of templatemo_main -->
    
<?php
include("footer.php");
 
?>
    
</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->

</body>
</html>