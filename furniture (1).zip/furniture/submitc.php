<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Unique Furniture</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />

<link rel="stylesheet" type="text/css" href="css/ddsmoothmenu.css" />

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/ddsmoothmenu.js">
</script>

<script type="text/javascript">

ddsmoothmenu.init({
	mainmenuid: "top_nav", //menu DIV id
	orientation: 'h', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu', //class added to menu's outer DIV
	//customtheme: ["#1c5a80", "#18374a"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})

</script>

</head>

<body>

<div id="templatemo_body_wrapper">
<div id="templatemo_wrapper">

<?php
include("header.php");
include("menubar.php");
?>
<html>
    <body>
        <div id="templatemo_main">
        <br>
<head>
<script language="JavaScript">
function numbersonly(myfield, e, dec)
{
	var key;
	var keychar;
	
	if (window.event)
	   key = window.event.keyCode;
	else if (e)
	   key = e.which;
	else
	   return true;
	keychar = String.fromCharCode(key);
	
	if ((key==null) || (key==0) || (key==8) || (key==9) || (key==13) || (key==27))
	   return true;
	else if ((("0123456789").indexOf(keychar) > -1))
	   return true;
	else if (dec && (keychar == "."))
    {
	   myfield.form.elements[dec].focus();
	   return false;
	}
	else
	   return false;
}</script>
</head>
<?php
echo "<form name='f1' action='smsg.php' method='GET'>";
echo "<font  style='Italic Bold' size=4><b><u>Payment mode</u></b> : Credit card(Visa/Master)</font>";
echo "<br>";
echo "<br><font  style='Italic Bold' size=4><b><u>Card type</u></b> : <input type='radio' name='r1' required value='Master card'>Master card<input type='radio' name='r1' value='Visa'>Visa</font>";
echo "<br><br><font  style='Italic Bold' size=4><b><u>Expiration date</u></b> : <select name='s1' required><option selected='selected'>Month</option><option>January</option><option>February</option><option>March</option><option>April</option><option>May</option><option>June</option><option>July</option><option>August</option><option>September</option><option>October</option><option>November</option><option>December</option></select> <select name='s2'><option selected='selected'>Year</option><option>2020</option><option>2021</option><option>2022</option><option>2023</option><option>2024</option><option>on wards</option></select></font>";
echo "<br><br><font  style='Italic Bold' size=4><b><u>Card number</u></b> : <input type='text' maxlength=20 name='t1' required onkeypress='return numbersonly(this, event)'></font>";



echo "<br><br><font style='Italic Bold' size=4><br><br><input type='submit' value='CONFORM ORDER' name='t4' onClick=numbersonly()></font>";
echo "</font>";
echo "</form>";

include("connection.php");
$d="delete from order_tb";
mysqli_query($db,$d)or die("can't delete");
?><br><br>
<div id="sidebar" class="float_l">
                    
          <div class="">
               
                       
            </div>
</body>
</html>
            <div class="cleaner"></div>         
        </div> 
        <div class="cleaner"></div>
    </div> <!-- END of templatemo_main -->

</body>
</html>
<?php
include("footer.php");
?>

</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->

</body>
</html>
