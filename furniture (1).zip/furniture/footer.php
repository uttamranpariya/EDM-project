
<html>
    <body>
        <div id="templatemo_footer">
    	<p><a href="index.php">Home</a> | <a href="products.php">Products</a> | <a href="about.php">About</a> | <a href="faqs.php">FAQs</a> | <a href="contact.php">Contact Us</a>
		</p>

    	 <p><a href="#">Unique furniture</a>
		 <div id="textbox"><strong><h5 align="center">unique Furniture:</strong><br/>
							Rajkot,<br/>
							uniquef@gmail.com<br/>
							</h5>
		<a href="#"<div id="textbox"><strong><h5 align="center">Developed By:</strong><br>
							Andipara Mital<br/>
							</h5></a>
		  <!-- Credit: www.templatemo.com --></div> <!-- END of templatemo_footer -->
</body>
</html>

    